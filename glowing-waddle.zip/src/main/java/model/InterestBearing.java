package model;

public interface InterestBearing {
    void applyInterest();
}
