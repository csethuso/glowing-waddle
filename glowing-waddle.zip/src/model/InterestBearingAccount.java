// removed: duplicate of InterestBearing interface now located at
// src/main/java/model/InterestBearing.java

